package com.example.demo.demo123.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.demo123.model.Ticket;
import com.example.demo.demo123.model.User;
import com.example.demo.demo123.repository.ITicketRepository;
import com.example.demo.demo123.repository.IUserRepository;
import com.example.demo.demo123.repository.TicketRepository;

@Service
public class TicketService implements ITicketService {
	
	@Autowired
	TicketRepository ticketRepository;
	
	@Autowired
	ITicketRepository iticketRepository;
	
	@Autowired
	IUserRepository iuserRepository;

	@Override
	public List<Ticket> listTickets() {
//		return ticketRepository.listTickets();
		
//		System.out.println(iticketRepository.getTickets());
//		iticketRepository.getTicketsByDestination("chennai").forEach(e->System.out.println(e));
//		iticketRepository.getPlaces().forEach(e->System.out.println(e));
//		iticketRepository.getAllTravels().forEach(e-> {
//			for(int i=0; i<e.length; i++) {
//				System.out.print(e[i]);
//			}
//			System.out.println();
//		});
		return iticketRepository.findAll();
	}

	@Override
	public Ticket bookTicket(Ticket ticket) {
		// TODO Auto-generated method stub
//		return ticketRepository.bookTicket(ticket);
		return iticketRepository.save(ticket);
	}

	@Override
	public int cancelTicket(int id) {
		// TODO Auto-generated method stub
		return ticketRepository.cancelTicket(id);
	}

	
	@Override
	public List<Ticket> getTicketsBySourceDest(String source, String dest) {
		return iticketRepository.findBySourceAndDestination(source, dest);
	}

	@Override
	public List<Ticket> getTicketsBySourceDestContains(String sourcePart, String destPart) {
		// TODO Auto-generated method stub
		return iticketRepository.findBySourceContainsAndDestinationContainsIgnoreCase(sourcePart, destPart);
	}

	@Override
	public List<User> getUsers() {
		return iuserRepository.findAll();
	}

	@Override
	public User createUser(User user) {
		return iuserRepository.save(user);
	}

	@Override
	public List<Ticket> listTicketsByNativeQuery() {
		return iticketRepository.getTicketsByNativeQuery();
	}

}
