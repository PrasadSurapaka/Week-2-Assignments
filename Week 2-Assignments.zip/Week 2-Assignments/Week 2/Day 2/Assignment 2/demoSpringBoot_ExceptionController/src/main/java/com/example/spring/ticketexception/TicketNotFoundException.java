package com.example.spring.ticketexception;

public class TicketNotFoundException {

}
