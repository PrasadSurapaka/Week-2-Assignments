package com.example.spring.ticketexception.controller;

public class TicketNotFoundExceptionController {

}
