package com.example.demo.demo123.model;

import org.springframework.stereotype.Component;

@Component
public class SourceDestination {
	private String source;
	private String destination;
	
	public SourceDestination() {
		
	}

	public SourceDestination(String source, String destination) {
		super();
		this.source = source;
		this.destination = destination;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	@Override
	public String toString() {
		return "SourceDestination [source=" + source + ", destination=" + destination + "]";
	}
	
	
}
