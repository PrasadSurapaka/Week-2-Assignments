package com.example.demo.demo123.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.demo123.model.User;

public interface IUserRepository extends JpaRepository<User, Integer> {

}
