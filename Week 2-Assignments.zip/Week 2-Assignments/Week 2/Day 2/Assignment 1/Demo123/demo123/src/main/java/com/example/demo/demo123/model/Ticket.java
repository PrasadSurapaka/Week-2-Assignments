package com.example.demo.demo123.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.stereotype.Component;


@Entity
public class Ticket {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	int id;
	String travelsName;
	String source;
	String destination;
	
	public Ticket() {
		
	}

	public Ticket(int id, String travelsName, String source, String destination) {
		super();
		this.id = id;
		this.travelsName = travelsName;
		this.source = source;
		this.destination = destination;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTravelsName() {
		return travelsName;
	}

	public void setTravelsName(String travelsName) {
		this.travelsName = travelsName;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	@Override
	public String toString() {
		return "Ticket [id=" + id + ", travelsName=" + travelsName + ", source=" + source + ", destination="
				+ destination + "]";
	}
	
	
}

