
com.app SpringBeaanAnno.java
package com.app;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;


import com.config.Config1;
import com.config.Config2;
import com.eg.A;
import com.eg.Employee;

public class SpringBeaanAnno {
	public static void main(String[] args) {
		AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(Config1.class, Config2.class);

		//ctx.register(MyConfig.class);
		ctx.refresh();
		
		Employee emp = ctx.getBean(Employee.class);
		emp.setName("fevbrgver");
		
		System.out.println(emp.getName());
		
		A oa = ctx.getBean(A.class, 100, 30.0f);
		System.out.println(oa);
		
	}
}

com.config  Config1.java
package com.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.eg.Employee;

@Configuration
public class Config1 {
	@Bean 
	@Scope("prototype")
	public Employee getEBean(){
		System.out.println("public Employee getEBean()");
		return new Employee();
	}
}

com.config --> Config2.java
package com.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;

import com.eg.A;

@Configuration
public class Config2 {
	@Lazy
	@Bean 
	@Scope("prototype")
	public A getA(int p1, float f1){
		return new A(p1, f1);
	}
}
-------------------------------com.eg --> A.java
package com.eg;

public class A{
	int p1;
	float f1;
	public A(int p1, float f1){
		this.p1 = p1;
		this.f1 = f1;
		System.out.println("A()"+p1 + " " + f1);
	}
	
	public void initBn(){
		System.out.println("initBn()...");
	}
	
	public void destroyBn(){
		System.out.println("destroyBn()...");
	}
	
	@Override
	public String toString(){
		return "a="+p1+f1;
	}
}
------------------com.eg 
 Employee.java
package com.eg;

public class Employee{
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Employee() {
		System.out.println("Employee() ");
	}
}